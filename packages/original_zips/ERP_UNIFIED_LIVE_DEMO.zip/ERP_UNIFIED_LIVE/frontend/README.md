# ERP Web Client – Phase 3.16 (Pagination UI)
Date: 2025-12-27

## Added
- Pagination controls (limit/offset) for requests list
