# ERP Web Client – Phase 3.15 (Posting Guards UI)
Date: 2025-12-26

## Added
- Can-Post check label + button (Check Post)
